import datetime

import discord
from discord import app_commands
from discord.ext import commands

import config
import storage


def ok_embed_view(title: str, desc: str, color: int = config.COLOR_SUCCESS) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView()
    view.add_item(discord.ui.Container(
        discord.ui.TextDisplay(f"### {title}\n{desc}"),
        accent_colour=color,
    ))
    return view


MUTE_ROLE_NAME = "Muted"


async def get_or_create_mute_role(guild: discord.Guild) -> discord.Role:
    role = discord.utils.get(guild.roles, name=MUTE_ROLE_NAME)
    if role:
        return role
    role = await guild.create_role(name=MUTE_ROLE_NAME, reason="Auto-created mute role")
    for channel in guild.channels:
        try:
            await channel.set_permissions(role, send_messages=False, speak=False, add_reactions=False)
        except discord.Forbidden:
            pass
    return role


class Moderation(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # -------- /ban : toggles whether the ban system is active on this server -------
    @app_commands.command(name="ban", description="เปิดหรือปิดระบบแบนสมาชิก")
    @app_commands.describe(state="เปิด หรือ ปิด ระบบแบน")
    @app_commands.choices(state=[
        app_commands.Choice(name="เปิด", value="on"),
        app_commands.Choice(name="ปิด", value="off"),
    ])
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.guild_only()
    async def ban_toggle(self, interaction: discord.Interaction, state: app_commands.Choice[str]):
        enabled = state.value == "on"
        storage.set_value(interaction.guild_id, "ban_system_enabled", enabled)
        await interaction.response.send_message(view=ok_embed_view(
            "ระบบแบน", f"ระบบแบนสมาชิกตอนนี้: **{'เปิดใช้งาน ✅' if enabled else 'ปิดใช้งาน ❌'}**"))

    # -------- /kick --------
    @app_commands.command(name="kick", description="เตะสมาชิกออกจากเซิร์ฟเวอร์")
    @app_commands.describe(member="สมาชิกที่ต้องการเตะ", reason="เหตุผล (ถ้ามี)")
    @app_commands.checks.has_permissions(kick_members=True)
    @app_commands.guild_only()
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "ไม่ระบุ"):
        if member.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
            return await interaction.response.send_message(
                view=ok_embed_view("ไม่สามารถทำได้", "ยศของสมาชิกสูงกว่าหรือเท่ากับคุณ", config.COLOR_DANGER),
                ephemeral=True)
        try:
            await member.kick(reason=f"{reason} | โดย {interaction.user}")
        except discord.Forbidden:
            return await interaction.response.send_message(
                view=ok_embed_view("ผิดพลาด", "บอทไม่มีสิทธิ์เพียงพอ", config.COLOR_DANGER), ephemeral=True)
        await interaction.response.send_message(view=ok_embed_view(
            "เตะสมาชิกสำเร็จ", f"เตะ {member.mention} ออกแล้ว\nเหตุผล: {reason}"))

    # -------- /mute --------
    @app_commands.command(name="mute", description="Mute สมาชิกตามระยะเวลาที่กำหนด หรือยกเลิก Mute")
    @app_commands.describe(
        member="สมาชิกที่ต้องการ mute",
        duration="ระยะเวลา เช่น 10m, 1h, 1d (เว้นว่างเพื่อยกเลิก mute)",
        reason="เหตุผล (ถ้ามี)")
    @app_commands.checks.has_permissions(moderate_members=True)
    @app_commands.guild_only()
    async def mute(self, interaction: discord.Interaction, member: discord.Member,
                    duration: str = None, reason: str = "ไม่ระบุ"):
        # unmute path
        if duration is None:
            try:
                await member.timeout(None, reason=f"ยกเลิก mute โดย {interaction.user}")
            except discord.Forbidden:
                return await interaction.response.send_message(
                    view=ok_embed_view("ผิดพลาด", "บอทไม่มีสิทธิ์เพียงพอ", config.COLOR_DANGER), ephemeral=True)
            return await interaction.response.send_message(
                view=ok_embed_view("ยกเลิก Mute แล้ว", f"{member.mention} สามารถพูดได้ตามปกติ"))

        unit = duration[-1].lower()
        try:
            amount = int(duration[:-1])
        except ValueError:
            return await interaction.response.send_message(
                view=ok_embed_view("รูปแบบผิด", "ใช้รูปแบบ เช่น `10m`, `1h`, `1d`", config.COLOR_DANGER),
                ephemeral=True)
        seconds = {"m": 60, "h": 3600, "d": 86400}.get(unit)
        if seconds is None:
            return await interaction.response.send_message(
                view=ok_embed_view("รูปแบบผิด", "หน่วยเวลาใช้ได้แค่ m, h, d", config.COLOR_DANGER),
                ephemeral=True)

        delta = datetime.timedelta(seconds=seconds * amount)
        if delta > datetime.timedelta(days=28):
            return await interaction.response.send_message(
                view=ok_embed_view("รูปแบบผิด", "Discord รองรับ timeout สูงสุด 28 วัน", config.COLOR_DANGER),
                ephemeral=True)
        try:
            await member.timeout(delta, reason=f"{reason} | โดย {interaction.user}")
        except discord.Forbidden:
            return await interaction.response.send_message(
                view=ok_embed_view("ผิดพลาด", "บอทไม่มีสิทธิ์เพียงพอ", config.COLOR_DANGER), ephemeral=True)
        until = discord.utils.format_dt(discord.utils.utcnow() + delta, "R")
        await interaction.response.send_message(view=ok_embed_view(
            "Mute สำเร็จ", f"{member.mention} ถูก mute จนถึง {until}\nเหตุผล: {reason}"))

    # -------- /purge --------
    @app_commands.command(name="purge", description="ลบข้อความในห้องตามจำนวนที่ระบุ สูงสุด 100 ข้อความ")
    @app_commands.describe(amount="จำนวนข้อความที่ต้องการลบ (1-100)", member="ลบเฉพาะข้อความของสมาชิกคนนี้ (ถ้ามี)")
    @app_commands.checks.has_permissions(manage_messages=True)
    @app_commands.guild_only()
    async def purge(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100],
                     member: discord.Member = None):
        await interaction.response.defer(ephemeral=True)
        check = (lambda m: m.author.id == member.id) if member else None
        deleted = await interaction.channel.purge(limit=amount, check=check)
        await interaction.followup.send(
            view=ok_embed_view("ลบข้อความสำเร็จ", f"ลบไปทั้งหมด **{len(deleted)}** ข้อความ"),
            ephemeral=True)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            msg = ok_embed_view("ไม่มีสิทธิ์", "คุณไม่มีสิทธิ์ใช้คำสั่งนี้", config.COLOR_DANGER)
            if interaction.response.is_done():
                await interaction.followup.send(view=msg, ephemeral=True)
            else:
                await interaction.response.send_message(view=msg, ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Moderation(bot))
