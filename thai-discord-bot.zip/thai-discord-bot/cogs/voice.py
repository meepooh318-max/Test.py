import discord
from discord import app_commands
from discord.ext import commands

import config
import storage


def status_view(title: str, desc: str, color: int = config.COLOR_SUCCESS) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView()
    view.add_item(discord.ui.Container(discord.ui.TextDisplay(f"### {title}\n{desc}"), accent_colour=color))
    return view


class Voice(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # -------- /voicechat : keep the bot connected to a voice channel 24/7 --------
    @app_commands.command(name="voicechat", description="ตั้งค่าบอทให้อยู่ในห้องเสียงแบบ 24/7")
    @app_commands.describe(channel="ห้องเสียงที่ต้องการให้บอทเข้าไปอยู่ตลอดเวลา (เว้นว่างเพื่อให้บอทออก)")
    @app_commands.checks.has_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def voicechat(self, interaction: discord.Interaction, channel: discord.VoiceChannel = None):
        guild = interaction.guild
        if channel is None:
            storage.set_value(guild.id, "voice_247_channel_id", None)
            if guild.voice_client:
                await guild.voice_client.disconnect(force=True)
            return await interaction.response.send_message(
                view=status_view("ปิดระบบ 24/7", "บอทออกจากห้องเสียงแล้ว"))

        storage.set_value(guild.id, "voice_247_channel_id", channel.id)
        if guild.voice_client:
            await guild.voice_client.move_to(channel)
        else:
            await channel.connect(self_deaf=True)
        await interaction.response.send_message(
            view=status_view("เปิดระบบ 24/7", f"บอทจะอยู่ในห้อง {channel.mention} ตลอดเวลา"))

    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member, before: discord.VoiceState,
                                     after: discord.VoiceState):
        if member.guild is None:
            return

        # reconnect the bot itself if it gets kicked/disconnected from its 24/7 channel
        if member.id == self.bot.user.id and after.channel is None:
            target_id = storage.get_value(member.guild.id, "voice_247_channel_id")
            if target_id:
                target = member.guild.get_channel(target_id)
                if target:
                    await target.connect(self_deaf=True)
            return

        if member.bot:
            return

        # join/leave logging
        log_channel_id = storage.get_value(member.guild.id, "voice_log_channel_id")
        if not log_channel_id:
            return
        log_channel = member.guild.get_channel(log_channel_id)
        if not log_channel:
            return

        if before.channel is None and after.channel is not None:
            text = f"🔊 {member.mention} เข้าห้องเสียง **{after.channel.name}**"
        elif before.channel is not None and after.channel is None:
            text = f"🔇 {member.mention} ออกจากห้องเสียง **{before.channel.name}**"
        elif before.channel != after.channel:
            text = f"🔁 {member.mention} ย้ายจาก **{before.channel.name}** ไป **{after.channel.name}**"
        else:
            return

        v = discord.ui.LayoutView()
        v.add_item(discord.ui.Container(discord.ui.TextDisplay(text), accent_colour=config.COLOR_PRIMARY))
        await log_channel.send(view=v)

    # -------- /ระบบบันทึก-เข้าออกห้อง --------
    @app_commands.command(name="ระบบบันทึก-เข้าออกห้อง", description="เปิดหรือปิดระบบบันทึกสมาชิกเข้าและออกห้องเสียง")
    @app_commands.describe(state="เปิด หรือ ปิด ระบบบันทึก", channel="ห้องที่จะส่ง log (จำเป็นเมื่อเปิด)")
    @app_commands.choices(state=[
        app_commands.Choice(name="เปิด", value="on"),
        app_commands.Choice(name="ปิด", value="off"),
    ])
    @app_commands.checks.has_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def voice_log_toggle(self, interaction: discord.Interaction, state: app_commands.Choice[str],
                                channel: discord.TextChannel = None):
        if state.value == "on":
            if channel is None:
                return await interaction.response.send_message(
                    view=status_view("ต้องระบุห้อง", "กรุณาระบุห้องที่จะส่ง log ด้วย", config.COLOR_DANGER),
                    ephemeral=True)
            storage.set_value(interaction.guild_id, "voice_log_channel_id", channel.id)
            msg = f"เปิดระบบบันทึกเข้าออกห้องเสียงแล้ว จะส่งไปที่ {channel.mention}"
        else:
            storage.set_value(interaction.guild_id, "voice_log_channel_id", None)
            msg = "ปิดระบบบันทึกเข้าออกห้องเสียงแล้ว"
        await interaction.response.send_message(view=status_view("ตั้งค่าสำเร็จ", msg))

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message(
                view=status_view("ไม่มีสิทธิ์", "คุณไม่มีสิทธิ์ใช้คำสั่งนี้", config.COLOR_DANGER), ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Voice(bot))
