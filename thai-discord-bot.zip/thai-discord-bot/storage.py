"""Very small JSON key-value store, namespaced per guild.

Good enough for a single-shard bot's settings (toggle flags, channel ids,
role ids, ticket counters, confession counters...). Swap for a real
database if you outgrow it.
"""
import json
import os
import threading

_PATH = os.path.join(os.path.dirname(__file__), "data", "store.json")
_lock = threading.Lock()


def _load() -> dict:
    if not os.path.exists(_PATH):
        return {}
    with open(_PATH, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}


def _save(data: dict) -> None:
    os.makedirs(os.path.dirname(_PATH), exist_ok=True)
    with open(_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def get_guild(guild_id: int) -> dict:
    with _lock:
        data = _load()
        return data.get(str(guild_id), {})


def set_guild(guild_id: int, updates: dict) -> dict:
    with _lock:
        data = _load()
        gid = str(guild_id)
        current = data.get(gid, {})
        current.update(updates)
        data[gid] = current
        _save(data)
        return current


def get_value(guild_id: int, key: str, default=None):
    return get_guild(guild_id).get(key, default)


def set_value(guild_id: int, key: str, value) -> None:
    set_guild(guild_id, {key: value})
