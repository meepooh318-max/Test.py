import discord
from discord import app_commands
from discord.ext import commands

import config


def status_view(title: str, desc: str, color: int = config.COLOR_SUCCESS) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView()
    view.add_item(discord.ui.Container(discord.ui.TextDisplay(f"### {title}\n{desc}"), accent_colour=color))
    return view


class Emoji(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="emoji", description="อัปโหลดรูปภาพและสร้างเป็นอีโมจิของเซิร์ฟเวอร์")
    @app_commands.describe(name="ชื่ออีโมจิ (2-32 ตัวอักษร, a-z, 0-9, _)", image="ไฟล์รูปภาพ (png, jpg, gif) ขนาดไม่เกิน 256KB")
    @app_commands.checks.has_permissions(manage_emojis_and_stickers=True)
    @app_commands.guild_only()
    async def emoji_cmd(self, interaction: discord.Interaction, name: str, image: discord.Attachment):
        if not image.content_type or not image.content_type.startswith("image/"):
            return await interaction.response.send_message(
                view=status_view("ไฟล์ไม่ถูกต้อง", "กรุณาแนบไฟล์รูปภาพ", config.COLOR_DANGER), ephemeral=True)
        if image.size > 256 * 1024:
            return await interaction.response.send_message(
                view=status_view("ไฟล์ใหญ่เกินไป", "Discord รองรับอีโมจิขนาดไม่เกิน 256KB", config.COLOR_DANGER),
                ephemeral=True)

        await interaction.response.defer()
        data = await image.read()
        try:
            new_emoji = await interaction.guild.create_custom_emoji(
                name=name, image=data, reason=f"สร้างโดย {interaction.user}")
        except discord.HTTPException as e:
            return await interaction.followup.send(
                view=status_view("สร้างอีโมจิไม่สำเร็จ", f"เกิดข้อผิดพลาด: {e.text}", config.COLOR_DANGER))

        v = discord.ui.LayoutView()
        v.add_item(discord.ui.Container(
            discord.ui.Section(
                discord.ui.TextDisplay(f"### สร้างอีโมจิสำเร็จ\n{new_emoji} `:{new_emoji.name}:`"),
                accessory=discord.ui.Thumbnail(media=new_emoji.url),
            ),
            accent_colour=config.COLOR_SUCCESS,
        ))
        await interaction.followup.send(view=v)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message(
                view=status_view("ไม่มีสิทธิ์", "คุณไม่มีสิทธิ์ใช้คำสั่งนี้", config.COLOR_DANGER), ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Emoji(bot))
