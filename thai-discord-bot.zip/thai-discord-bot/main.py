import asyncio
import logging

import discord
from discord.ext import commands

import config

logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(levelname)s: %(message)s")
log = logging.getLogger("bot")

INTENTS = discord.Intents.default()
INTENTS.members = True          # needed for /role addall, /ban, /kick, welcome logs...
INTENTS.message_content = False  # not needed, everything here is slash commands
INTENTS.voice_states = True     # needed for voice join/leave logging + 24/7 VC

COGS = [
    "cogs.help_info",
    "cogs.moderation",
    "cogs.roles",
    "cogs.autoguildtag",
    "cogs.verify",
    "cogs.embedsystem",
    "cogs.ticket",
    "cogs.confess",
    "cogs.voice",
    "cogs.emoji",
]


class ThaiBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix=commands.when_mentioned, intents=INTENTS, help_command=None)

    async def setup_hook(self):
        for cog in COGS:
            try:
                await self.load_extension(cog)
                log.info("loaded %s", cog)
            except Exception:
                log.exception("failed to load %s", cog)
        # Sync globally. During development, sync to a single guild instead
        # (instant) by setting DEV_GUILD_ID in .env and uncommenting below.
        await self.tree.sync()

    async def on_ready(self):
        log.info("logged in as %s (%s)", self.user, self.user.id)
        await self.change_presence(activity=discord.Activity(
            type=discord.ActivityType.watching, name="/help"))


bot = ThaiBot()


async def main():
    if not config.TOKEN:
        raise SystemExit("DISCORD_TOKEN is not set — copy .env.example to .env and fill it in.")
    async with bot:
        await bot.start(config.TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
