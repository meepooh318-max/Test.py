import discord
from discord import app_commands
from discord.ext import commands

import config


class EmbedSystem(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="embedsystem", description="แสดงวิธีป้องกันการใช้แอปภายนอกในห้อง")
    @app_commands.checks.has_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def embedsystem(self, interaction: discord.Interaction):
        container = discord.ui.Container(
            discord.ui.TextDisplay("## 🔒 ป้องกันการใช้แอปภายนอก (External Apps) ในห้องนี้"),
            discord.ui.Separator(),
            discord.ui.TextDisplay(
                "1. ไปที่ **ตั้งค่าห้อง (Edit Channel)** ของห้องที่ต้องการ\n"
                "2. เลือกแท็บ **สิทธิ์ (Permissions)**\n"
                "3. เพิ่มยศหรือ `@everyone` แล้วปิดสิทธิ์ **Use External Apps**\n"
                "4. บันทึกการตั้งค่า — สมาชิกในห้องนี้จะไม่สามารถใช้ apps/integrations "
                "ภายนอก (เช่นบอทอื่นที่ผูกกับข้อความ) ได้อีก"
            ),
            discord.ui.Separator(),
            discord.ui.TextDisplay(
                "-# เคล็ดลับ: ปิดสิทธิ์นี้ในห้องที่ไม่ต้องการให้มีปุ่ม/embed จากแอปภายนอกปรากฏ "
                "แต่ embed จากบอทของเซิร์ฟเวอร์เอง (เช่นบอทนี้) จะไม่ได้รับผลกระทบ"
            ),
            accent_colour=config.COLOR_PRIMARY,
        )
        view = discord.ui.LayoutView()
        view.add_item(container)
        await interaction.response.send_message(view=view)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            v = discord.ui.LayoutView()
            v.add_item(discord.ui.Container(
                discord.ui.TextDisplay("### ไม่มีสิทธิ์\nคุณไม่มีสิทธิ์ใช้คำสั่งนี้"),
                accent_colour=config.COLOR_DANGER))
            await interaction.response.send_message(view=v, ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(EmbedSystem(bot))
