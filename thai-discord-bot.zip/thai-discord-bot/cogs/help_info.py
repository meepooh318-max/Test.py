import time

import discord
from discord import app_commands
from discord.ext import commands

import config

START_TIME = time.time()

# --- command reference shown by /help, one entry per command in the spec ---
HELP_SECTIONS = [
    ("ทั่วไป", [
        ("/help", "เปิดเมนูช่วยเหลือและดูคำอธิบายคำสั่งทั้งหมด"),
        ("/info", "แสดงข้อมูลพื้นฐานของบอท จำนวนเซิร์ฟเวอร์ จำนวนสมาชิก และเวอร์ชันบอท"),
        ("/serverinfo", "แสดงข้อมูลเซิร์ฟเวอร์ เช่น สมาชิก ช่อง บูสต์ และยศต่าง ๆ"),
        ("/user", "ดูข้อมูลสมาชิก Profile, Banner, ข้อมูลทั่วไป หรือยศ"),
    ]),
    ("การดูแลระบบ", [
        ("/ban", "เปิดหรือปิดระบบแบนสมาชิก"),
        ("/kick", "เตะสมาชิกออกจากเซิร์ฟเวอร์"),
        ("/mute", "Mute สมาชิกตามระยะเวลาที่กำหนด หรือยกเลิก Mute"),
        ("/purge", "ลบข้อความในห้องตามจำนวนที่ระบุ สูงสุด 100 ข้อความ"),
    ]),
    ("ระบบยศ", [
        ("/role addall", "มอบยศที่เลือกให้สมาชิกทุกคนในเซิร์ฟเวอร์"),
        ("/role removeall", "ดึงยศที่เลือกออกจากสมาชิกทุกคนในเซิร์ฟเวอร์"),
        ("/role add", "มอบยศให้สมาชิกที่เลือก"),
        ("/role remove", "ดึงยศออกจากสมาชิกที่เลือก"),
        ("/สร้างยศ77", "สร้างยศสำหรับ 77 จังหวัดของประเทศไทย"),
        ("/ระบบรับยศ77", "ส่งเมนูให้สมาชิกเลือกยศ 77 จังหวัด"),
        ("/autoguildtag", "ตั้งค่ามอบยศอัตโนมัติเมื่อสมาชิกใส่ Server Tag"),
    ]),
    ("ระบบเซิร์ฟเวอร์", [
        ("/setup-verify", "ติดตั้งระบบยืนยันตัวตนสมาชิก"),
        ("/embedsystem", "แสดงวิธีป้องกันการใช้แอปภายนอกในห้อง"),
        ("/ticket-setup", "ติดตั้งและตั้งค่าระบบ Ticket สำหรับรับเรื่องจากสมาชิก"),
        ("/confess_setup", "ติดตั้งระบบฝากบอกแบบไม่ระบุตัวตน"),
        ("/voicechat", "ตั้งค่าบอทให้อยู่ในห้องเสียงแบบ 24/7"),
        ("/ระบบบันทึก-เข้าออกห้อง", "เปิดหรือปิดระบบบันทึกสมาชิกเข้าและออกห้องเสียง"),
        ("/emoji", "อัปโหลดรูปภาพและสร้างเป็นอีโมจิของเซิร์ฟเวอร์"),
    ]),
]


def _section_container(title: str, rows: list[tuple[str, str]]) -> discord.ui.Container:
    lines = "\n".join(f"**`{name}`**\n{desc}" for name, desc in rows)
    return discord.ui.Container(
        discord.ui.TextDisplay(f"### {title}"),
        discord.ui.Separator(),
        discord.ui.TextDisplay(lines),
        accent_colour=config.COLOR_PRIMARY,
    )


class CategorySelect(discord.ui.Select):
    def __init__(self, outer: "HelpView"):
        self.outer = outer
        super().__init__(
            placeholder="เลือกหมวดคำสั่ง...",
            options=[discord.SelectOption(label=title, value=str(i))
                     for i, (title, _) in enumerate(HELP_SECTIONS)],
        )

    async def callback(self, interaction: discord.Interaction):
        idx = int(self.values[0])
        title, rows = HELP_SECTIONS[idx]
        self.outer.body.content = "\n".join(f"**`{n}`**\n{d}" for n, d in rows)
        self.outer.header.content = f"### 📖 {title}"
        await interaction.response.edit_message(view=self.outer)


class HelpView(discord.ui.LayoutView):
    def __init__(self):
        super().__init__(timeout=180)
        self.header = discord.ui.TextDisplay("### 📖 ทั่วไป")
        self.body = discord.ui.TextDisplay(
            "\n".join(f"**`{n}`**\n{d}" for n, d in HELP_SECTIONS[0][1]))
        container = discord.ui.Container(
            discord.ui.TextDisplay("## เมนูช่วยเหลือ"),
            self.header,
            discord.ui.Separator(),
            self.body,
            discord.ui.ActionRow(CategorySelect(self)),
            accent_colour=config.COLOR_PRIMARY,
        )
        self.add_item(container)


class HelpInfo(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="help", description="เปิดเมนูช่วยเหลือและดูคำอธิบายคำสั่งทั้งหมด")
    async def help_cmd(self, interaction: discord.Interaction):
        await interaction.response.send_message(view=HelpView())

    @app_commands.command(name="info", description="แสดงข้อมูลพื้นฐานของบอท")
    async def info_cmd(self, interaction: discord.Interaction):
        bot = self.bot
        uptime = int(time.time() - START_TIME)
        h, rem = divmod(uptime, 3600)
        m, s = divmod(rem, 60)
        member_count = sum(g.member_count or 0 for g in bot.guilds)

        container = discord.ui.Container(
            discord.ui.Section(
                discord.ui.TextDisplay(f"## {bot.user.name}"),
                discord.ui.TextDisplay(
                    f"เวอร์ชันบอท: `{config.BOT_VERSION}`\n"
                    f"เซิร์ฟเวอร์ทั้งหมด: **{len(bot.guilds)}**\n"
                    f"สมาชิกทั้งหมด: **{member_count}**\n"
                    f"เวลาทำงาน: **{h}h {m}m {s}s**\n"
                    f"Ping: **{round(bot.latency * 1000)}ms**"
                ),
                accessory=discord.ui.Thumbnail(media=bot.user.display_avatar.url),
            ),
            accent_colour=config.COLOR_PRIMARY,
        )
        view = discord.ui.LayoutView()
        view.add_item(container)
        await interaction.response.send_message(view=view)

    @app_commands.command(name="serverinfo", description="แสดงข้อมูลเซิร์ฟเวอร์")
    @app_commands.guild_only()
    async def serverinfo_cmd(self, interaction: discord.Interaction):
        guild = interaction.guild
        text_ch = len(guild.text_channels)
        voice_ch = len(guild.voice_channels)
        roles = len(guild.roles)

        container = discord.ui.Container(
            discord.ui.Section(
                discord.ui.TextDisplay(f"## {guild.name}"),
                discord.ui.TextDisplay(
                    f"เจ้าของ: <@{guild.owner_id}>\n"
                    f"สมาชิกทั้งหมด: **{guild.member_count}**\n"
                    f"ช่องข้อความ: **{text_ch}** | ช่องเสียง: **{voice_ch}**\n"
                    f"ยศทั้งหมด: **{roles}**\n"
                    f"ระดับบูสต์: **{guild.premium_tier}** "
                    f"({guild.premium_subscription_count or 0} boosts)\n"
                    f"สร้างเมื่อ: <t:{int(guild.created_at.timestamp())}:D>"
                ),
                accessory=discord.ui.Thumbnail(media=guild.icon.url) if guild.icon else None,
            ),
            accent_colour=config.COLOR_PRIMARY,
        )
        view = discord.ui.LayoutView()
        view.add_item(container)
        await interaction.response.send_message(view=view)

    @app_commands.command(name="user", description="ดูข้อมูลสมาชิก Profile, Banner, ยศ")
    @app_commands.describe(member="สมาชิกที่ต้องการดูข้อมูล (ค่าเริ่มต้นคือตัวคุณเอง)")
    @app_commands.guild_only()
    async def user_cmd(self, interaction: discord.Interaction, member: discord.Member = None):
        member = member or interaction.user
        # banner is only present on a fully-fetched User object
        fetched = await self.bot.fetch_user(member.id)
        roles = [r.mention for r in reversed(member.roles) if r != interaction.guild.default_role]

        items = [
            discord.ui.Section(
                discord.ui.TextDisplay(f"## {member}"),
                discord.ui.TextDisplay(
                    f"ID: `{member.id}`\n"
                    f"เข้าเซิร์ฟเวอร์เมื่อ: <t:{int(member.joined_at.timestamp())}:R>\n"
                    f"สร้างบัญชีเมื่อ: <t:{int(member.created_at.timestamp())}:R>\n"
                    f"ยศ ({len(roles)}): {' '.join(roles) if roles else '-'}"
                ),
                accessory=discord.ui.Thumbnail(media=member.display_avatar.url),
            ),
        ]
        if fetched.banner:
            items.append(discord.ui.Separator())
            items.append(discord.ui.MediaGallery(discord.MediaGalleryItem(fetched.banner.url)))

        container = discord.ui.Container(*items, accent_colour=config.COLOR_PRIMARY)
        view = discord.ui.LayoutView()
        view.add_item(container)
        await interaction.response.send_message(view=view)


async def setup(bot: commands.Bot):
    await bot.add_cog(HelpInfo(bot))
