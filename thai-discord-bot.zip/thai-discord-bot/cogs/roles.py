import asyncio

import discord
from discord import app_commands
from discord.ext import commands

import config

PROVINCE_ROLE_PREFIX = ""  # set e.g. "จังหวัด " if you want a prefix on the role name
CHUNK_SIZE = 25  # Discord select menus allow at most 25 options


def status_view(title: str, desc: str, color: int = config.COLOR_SUCCESS) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView()
    view.add_item(discord.ui.Container(discord.ui.TextDisplay(f"### {title}\n{desc}"), accent_colour=color))
    return view


def _chunks(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


class ProvinceSelect(discord.ui.Select):
    """One dropdown covering a slice of the 77 provinces. Selecting a province
    toggles that role: on if the member didn't have it, off if they did."""

    def __init__(self, group_index: int, provinces: list[str]):
        options = [discord.SelectOption(label=p, value=p) for p in provinces]
        super().__init__(
            placeholder=f"จังหวัด (กลุ่มที่ {group_index + 1})...",
            options=options,
            min_values=0,
            max_values=len(options),
            custom_id=f"province_select_{group_index}",
        )

    async def callback(self, interaction: discord.Interaction):
        guild = interaction.guild
        member = interaction.user
        chosen = set(self.values)
        group_role_names = {opt.value for opt in self.options}

        to_add, to_remove = [], []
        for name in group_role_names:
            role = discord.utils.get(guild.roles, name=PROVINCE_ROLE_PREFIX + name)
            if role is None:
                continue
            has_it = role in member.roles
            wants_it = name in chosen
            if wants_it and not has_it:
                to_add.append(role)
            elif not wants_it and has_it:
                to_remove.append(role)

        if to_add:
            await member.add_roles(*to_add, reason="เลือกยศจังหวัด")
        if to_remove:
            await member.remove_roles(*to_remove, reason="ยกเลิกยศจังหวัด")

        summary = []
        if to_add:
            summary.append("เพิ่ม: " + ", ".join(r.mention for r in to_add))
        if to_remove:
            summary.append("เอาออก: " + ", ".join(r.mention for r in to_remove))
        await interaction.response.send_message(
            "\n".join(summary) if summary else "ไม่มีการเปลี่ยนแปลง", ephemeral=True)


class ProvinceRoleView(discord.ui.LayoutView):
    """Persistent view — register with bot.add_view(ProvinceRoleView()) so the
    dropdowns keep working after a restart."""

    def __init__(self):
        super().__init__(timeout=None)
        rows = [discord.ui.ActionRow(ProvinceSelect(i, chunk))
                for i, chunk in enumerate(_chunks(config.THAI_PROVINCES, CHUNK_SIZE))]
        container = discord.ui.Container(
            discord.ui.TextDisplay("## 🇹🇭 เลือกยศจังหวัดของคุณ\nเลือกจังหวัดที่ต้องการจากเมนูด้านล่าง (เลือกได้จากทุกกลุ่ม)"),
            discord.ui.Separator(),
            *rows,
            accent_colour=config.COLOR_PRIMARY,
        )
        self.add_item(container)


class Roles(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    role_group = app_commands.Group(name="role", description="จัดการยศสมาชิก")

    @role_group.command(name="add", description="มอบยศให้สมาชิกที่เลือก")
    @app_commands.checks.has_permissions(manage_roles=True)
    @app_commands.guild_only()
    async def role_add(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        await member.add_roles(role, reason=f"โดย {interaction.user}")
        await interaction.response.send_message(view=status_view("มอบยศสำเร็จ", f"มอบยศ {role.mention} ให้ {member.mention}"))

    @role_group.command(name="remove", description="ดึงยศออกจากสมาชิกที่เลือก")
    @app_commands.checks.has_permissions(manage_roles=True)
    @app_commands.guild_only()
    async def role_remove(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        await member.remove_roles(role, reason=f"โดย {interaction.user}")
        await interaction.response.send_message(view=status_view("ดึงยศสำเร็จ", f"ดึงยศ {role.mention} ออกจาก {member.mention}"))

    @role_group.command(name="addall", description="มอบยศที่เลือกให้สมาชิกทุกคนในเซิร์ฟเวอร์")
    @app_commands.checks.has_permissions(manage_roles=True, manage_guild=True)
    @app_commands.guild_only()
    async def role_addall(self, interaction: discord.Interaction, role: discord.Role):
        await interaction.response.defer()
        members = [m for m in interaction.guild.members if role not in m.roles and not m.bot]
        count = 0
        for m in members:
            try:
                await m.add_roles(role, reason=f"addall โดย {interaction.user}")
                count += 1
                await asyncio.sleep(0.25)  # be gentle on the ratelimit for big servers
            except discord.HTTPException:
                continue
        await interaction.followup.send(view=status_view("มอบยศทั้งเซิร์ฟเวอร์สำเร็จ", f"มอบยศ {role.mention} ให้สมาชิก **{count}** คน"))

    @role_group.command(name="removeall", description="ดึงยศที่เลือกออกจากสมาชิกทุกคนในเซิร์ฟเวอร์")
    @app_commands.checks.has_permissions(manage_roles=True, manage_guild=True)
    @app_commands.guild_only()
    async def role_removeall(self, interaction: discord.Interaction, role: discord.Role):
        await interaction.response.defer()
        members = [m for m in interaction.guild.members if role in m.roles]
        count = 0
        for m in members:
            try:
                await m.remove_roles(role, reason=f"removeall โดย {interaction.user}")
                count += 1
                await asyncio.sleep(0.25)
            except discord.HTTPException:
                continue
        await interaction.followup.send(view=status_view("ดึงยศทั้งเซิร์ฟเวอร์สำเร็จ", f"ดึงยศ {role.mention} จากสมาชิก **{count}** คน"))

    @app_commands.command(name="สร้างยศ77", description="สร้างยศสำหรับ 77 จังหวัดของประเทศไทย")
    @app_commands.checks.has_permissions(manage_roles=True)
    @app_commands.guild_only()
    async def create_province_roles(self, interaction: discord.Interaction):
        await interaction.response.defer()
        guild = interaction.guild
        created, skipped = 0, 0
        for name in config.THAI_PROVINCES:
            full_name = PROVINCE_ROLE_PREFIX + name
            if discord.utils.get(guild.roles, name=full_name):
                skipped += 1
                continue
            await guild.create_role(name=full_name, reason=f"สร้างยศ77 โดย {interaction.user}")
            created += 1
            await asyncio.sleep(0.3)
        await interaction.followup.send(view=status_view(
            "สร้างยศ 77 จังหวัดเสร็จสิ้น", f"สร้างใหม่ **{created}** ยศ, ข้ามที่มีอยู่แล้ว **{skipped}** ยศ"))

    @app_commands.command(name="ระบบรับยศ77", description="ส่งเมนูให้สมาชิกเลือกยศ 77 จังหวัด")
    @app_commands.checks.has_permissions(manage_roles=True)
    @app_commands.guild_only()
    async def province_role_menu(self, interaction: discord.Interaction):
        missing = [p for p in config.THAI_PROVINCES
                   if not discord.utils.get(interaction.guild.roles, name=PROVINCE_ROLE_PREFIX + p)]
        if missing:
            return await interaction.response.send_message(
                view=status_view("ยังไม่มียศจังหวัด", "กรุณารันคำสั่ง `/สร้างยศ77` ก่อนใช้งานเมนูนี้", config.COLOR_DANGER),
                ephemeral=True)
        await interaction.response.send_message(view=ProvinceRoleView())

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            msg = status_view("ไม่มีสิทธิ์", "คุณไม่มีสิทธิ์ใช้คำสั่งนี้", config.COLOR_DANGER)
            target = interaction.followup if interaction.response.is_done() else interaction.response
            await target.send(view=msg, ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Roles(bot))
    bot.add_view(ProvinceRoleView())  # keep dropdowns alive across restarts
