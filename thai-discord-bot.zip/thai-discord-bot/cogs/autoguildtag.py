import discord
from discord import app_commands
from discord.ext import commands

import config
import storage


def status_view(title: str, desc: str, color: int = config.COLOR_SUCCESS) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView()
    view.add_item(discord.ui.Container(discord.ui.TextDisplay(f"### {title}\n{desc}"), accent_colour=color))
    return view


class AutoGuildTag(commands.Cog):
    """Gives a role automatically to members whose profile is displaying this
    server's Server Tag (the little badge next to a username, introduced by
    Discord in 2024 as part of the "Guild Tags" / clan tags feature)."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="autoguildtag", description="ตั้งค่ามอบยศอัตโนมัติเมื่อสมาชิกใส่ Server Tag")
    @app_commands.describe(role="ยศที่จะมอบให้อัตโนมัติเมื่อสมาชิกใส่ Server Tag ของเซิร์ฟเวอร์นี้")
    @app_commands.checks.has_permissions(manage_roles=True)
    @app_commands.guild_only()
    async def autoguildtag(self, interaction: discord.Interaction, role: discord.Role):
        storage.set_value(interaction.guild_id, "guild_tag_role_id", role.id)
        await interaction.response.send_message(view=status_view(
            "ตั้งค่าสำเร็จ",
            f"สมาชิกที่เปิดใช้ Server Tag ของเซิร์ฟเวอร์นี้จะได้รับยศ {role.mention} อัตโนมัติ\n"
            f"-# บอทต้องเปิด Presence Intent และตรวจสอบสมาชิกที่ออนไลน์เพื่อให้ทำงานได้ครบถ้วน"))

    @commands.Cog.listener()
    async def on_presence_update(self, before: discord.Member, after: discord.Member):
        await self._sync_tag_role(after)

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        await self._sync_tag_role(after)

    async def _sync_tag_role(self, member: discord.Member):
        if member.bot or member.guild is None:
            return
        role_id = storage.get_value(member.guild.id, "guild_tag_role_id")
        if not role_id:
            return
        role = member.guild.get_role(role_id)
        if role is None:
            return

        # discord.py exposes the primary guild identity ("clan"/server tag) via
        # Member.primary_guild — check against this server's own id.
        primary_guild = getattr(member, "primary_guild", None)
        has_tag = bool(primary_guild and primary_guild.identity_enabled
                       and primary_guild.guild_id == member.guild.id)

        if has_tag and role not in member.roles:
            await member.add_roles(role, reason="แสดง Server Tag ของเซิร์ฟเวอร์")
        elif not has_tag and role in member.roles:
            await member.remove_roles(role, reason="ไม่ได้แสดง Server Tag ของเซิร์ฟเวอร์แล้ว")


async def setup(bot: commands.Bot):
    await bot.add_cog(AutoGuildTag(bot))
