import asyncio

import discord
from discord import app_commands
from discord.ext import commands

import config
import storage


def status_view(title: str, desc: str, color: int = config.COLOR_SUCCESS) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView()
    view.add_item(discord.ui.Container(discord.ui.TextDisplay(f"### {title}\n{desc}"), accent_colour=color))
    return view


class OpenTicketButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="เปิด Ticket", style=discord.ButtonStyle.primary,
                          emoji="🎫", custom_id="ticket_open")

    async def callback(self, interaction: discord.Interaction):
        guild = interaction.guild
        settings = storage.get_guild(guild.id)
        category_id = settings.get("ticket_category_id")
        support_role_id = settings.get("ticket_support_role_id")
        category = guild.get_channel(category_id) if category_id else None

        # one open ticket per member
        existing = discord.utils.get(guild.text_channels, name=f"ticket-{interaction.user.id}")
        if existing:
            return await interaction.response.send_message(
                f"คุณมี ticket ที่เปิดอยู่แล้ว: {existing.mention}", ephemeral=True)

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True,
                                                            read_message_history=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True),
        }
        if support_role_id:
            role = guild.get_role(support_role_id)
            if role:
                overwrites[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True)

        channel = await guild.create_text_channel(
            name=f"ticket-{interaction.user.id}",
            category=category,
            overwrites=overwrites,
            topic=f"Ticket ของ {interaction.user} ({interaction.user.id})",
            reason="เปิด ticket ใหม่",
        )

        container = discord.ui.Container(
            discord.ui.TextDisplay(
                f"## 🎫 Ticket ของ {interaction.user.mention}\nทีมงานจะเข้ามาช่วยเหลือคุณโดยเร็วที่สุด "
                f"กรุณาอธิบายปัญหาหรือคำขอของคุณ"),
            discord.ui.Separator(),
            discord.ui.ActionRow(ClaimButton(), CloseButton()),
            accent_colour=config.COLOR_PRIMARY,
        )
        v = discord.ui.LayoutView()
        v.add_item(container)
        mention = f"<@&{support_role_id}>" if support_role_id else ""
        await channel.send(content=mention or None, view=v)
        await interaction.response.send_message(f"เปิด ticket แล้ว: {channel.mention}", ephemeral=True)


class ClaimButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="รับเรื่อง", style=discord.ButtonStyle.secondary,
                          emoji="🙋", custom_id="ticket_claim")

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_message(f"{interaction.user.mention} รับเรื่องนี้แล้ว")


class CloseButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="ปิด Ticket", style=discord.ButtonStyle.danger,
                          emoji="🔒", custom_id="ticket_close")

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_message("กำลังปิด ticket ใน 5 วินาที...")
        await interaction.channel.edit(name=f"closed-{interaction.channel.name}")
        await asyncio.sleep(5)
        await interaction.channel.delete(reason=f"ปิด ticket โดย {interaction.user}")


class TicketPanelView(discord.ui.LayoutView):
    def __init__(self):
        super().__init__(timeout=None)
        container = discord.ui.Container(
            discord.ui.TextDisplay("## 🎫 ระบบ Ticket\nกดปุ่มด้านล่างเพื่อติดต่อทีมงาน"),
            discord.ui.Separator(),
            discord.ui.ActionRow(OpenTicketButton()),
            accent_colour=config.COLOR_PRIMARY,
        )
        self.add_item(container)


class Ticket(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="ticket-setup", description="ติดตั้งและตั้งค่าระบบ Ticket สำหรับรับเรื่องจากสมาชิก")
    @app_commands.describe(
        channel="ห้องที่จะส่งข้อความเปิด ticket (ค่าเริ่มต้นคือห้องนี้)",
        category="หมวดหมู่ (category) ที่จะสร้างห้อง ticket ไว้ข้างใน",
        support_role="ยศทีมงานที่จะเห็น ticket ทุกอัน (ถ้ามี)")
    @app_commands.checks.has_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def ticket_setup(self, interaction: discord.Interaction, channel: discord.TextChannel = None,
                            category: discord.CategoryChannel = None, support_role: discord.Role = None):
        channel = channel or interaction.channel
        storage.set_guild(interaction.guild_id, {
            "ticket_category_id": category.id if category else None,
            "ticket_support_role_id": support_role.id if support_role else None,
        })
        await channel.send(view=TicketPanelView())
        await interaction.response.send_message(
            view=status_view("ติดตั้งสำเร็จ", f"ระบบ Ticket ถูกส่งไปที่ {channel.mention} แล้ว"), ephemeral=True)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message(
                view=status_view("ไม่มีสิทธิ์", "คุณไม่มีสิทธิ์ใช้คำสั่งนี้", config.COLOR_DANGER), ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Ticket(bot))
    bot.add_view(TicketPanelView())
