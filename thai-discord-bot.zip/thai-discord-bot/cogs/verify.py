import discord
from discord import app_commands
from discord.ext import commands

import config
import storage


def status_view(title: str, desc: str, color: int = config.COLOR_SUCCESS) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView()
    view.add_item(discord.ui.Container(discord.ui.TextDisplay(f"### {title}\n{desc}"), accent_colour=color))
    return view


class VerifyButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="ยืนยันตัวตน", style=discord.ButtonStyle.success,
                          emoji="✅", custom_id="verify_button")

    async def callback(self, interaction: discord.Interaction):
        role_id = storage.get_value(interaction.guild_id, "verify_role_id")
        if not role_id:
            return await interaction.response.send_message("ยังไม่ได้ตั้งค่ายศยืนยันตัวตน", ephemeral=True)
        role = interaction.guild.get_role(role_id)
        if role is None:
            return await interaction.response.send_message("ไม่พบยศยืนยันตัวตน กรุณาติดต่อแอดมิน", ephemeral=True)
        if role in interaction.user.roles:
            return await interaction.response.send_message("คุณยืนยันตัวตนแล้ว ✅", ephemeral=True)
        await interaction.user.add_roles(role, reason="ยืนยันตัวตนผ่านระบบ")
        await interaction.response.send_message("ยืนยันตัวตนสำเร็จ ยินดีต้อนรับ! 🎉", ephemeral=True)


class VerifyView(discord.ui.LayoutView):
    def __init__(self):
        super().__init__(timeout=None)
        container = discord.ui.Container(
            discord.ui.TextDisplay(
                "## ✅ ยืนยันตัวตน\nกดปุ่มด้านล่างเพื่อยืนยันตัวตนและรับสิทธิ์เข้าถึงเซิร์ฟเวอร์"),
            discord.ui.Separator(),
            discord.ui.ActionRow(VerifyButton()),
            accent_colour=config.COLOR_PRIMARY,
        )
        self.add_item(container)


class Verify(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="setup-verify", description="ติดตั้งระบบยืนยันตัวตนสมาชิก")
    @app_commands.describe(role="ยศที่จะมอบให้เมื่อยืนยันตัวตนสำเร็จ",
                            channel="ห้องที่จะส่งข้อความยืนยันตัวตน (ค่าเริ่มต้นคือห้องนี้)")
    @app_commands.checks.has_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def setup_verify(self, interaction: discord.Interaction, role: discord.Role,
                            channel: discord.TextChannel = None):
        channel = channel or interaction.channel
        storage.set_value(interaction.guild_id, "verify_role_id", role.id)
        await channel.send(view=VerifyView())
        await interaction.response.send_message(
            view=status_view("ติดตั้งสำเร็จ", f"ระบบยืนยันตัวตนถูกส่งไปที่ {channel.mention} แล้ว"),
            ephemeral=True)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message(
                view=status_view("ไม่มีสิทธิ์", "คุณไม่มีสิทธิ์ใช้คำสั่งนี้", config.COLOR_DANGER), ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Verify(bot))
    bot.add_view(VerifyView())
