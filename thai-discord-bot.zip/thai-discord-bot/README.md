# Thai Discord Bot (Components V2)

บอทตัวอย่างที่ทำครบทุกคำสั่งตามสเปคที่ให้มา โดยเมนู/การ์ดต่าง ๆ ในบอทถูกสร้างด้วย
**Components V2** ของ Discord (`discord.ui.Container`, `discord.ui.LayoutView`,
`discord.ui.Section`, `discord.ui.ActionRow` ฯลฯ) แทน `discord.Embed` แบบเดิม

## โครงสร้างโปรเจกต์
```
main.py            จุดเริ่มโปรแกรม โหลด cogs และซิงก์ slash commands
config.py           ค่าคงที่ (สี, รายชื่อ 77 จังหวัด, เวอร์ชัน)
storage.py           ที่เก็บค่าตั้งค่าต่อเซิร์ฟเวอร์แบบ JSON (data/store.json)
cogs/
  help_info.py        /help /info /serverinfo /user
  moderation.py        /ban /kick /mute /purge
  roles.py              /role add|remove|addall|removeall, /สร้างยศ77, /ระบบรับยศ77
  autoguildtag.py        /autoguildtag
  verify.py                /setup-verify
  embedsystem.py            /embedsystem
  ticket.py                  /ticket-setup
  confess.py                  /confess_setup
  voice.py                     /voicechat, /ระบบบันทึก-เข้าออกห้อง
  emoji.py                      /emoji
```

## ติดตั้ง

1. **สำคัญ**: Components V2 (`discord.ui.Container` / `LayoutView`) ยังใหม่มาก
   และยังไม่มีใน `discord.py` เวอร์ชันเสถียรบน PyPI ณ ตอนที่เขียนโค้ดนี้ ให้ติดตั้ง
   จาก GitHub โดยตรง:

   ```bash
   python -m venv venv
   source venv/bin/activate      # Windows: venv\Scripts\activate
   pip install -U "git+https://github.com/Rapptz/discord.py"
   pip install -r requirements.txt
   ```

   ถ้าไม่อยากยุ่งกับเวอร์ชัน dev สามารถสลับกลับไปใช้ `discord.Embed` แบบเดิมได้
   — โค้ดทุกจุดที่สร้างการ์ดถูกแยกเป็นฟังก์ชัน `status_view(...)` /
   `*_View` class เดียว ทำให้แก้แค่จุดเดียวต่อไฟล์

2. คัดลอก `.env.example` เป็น `.env` แล้วใส่ token ของบอท:
   ```
   DISCORD_TOKEN=your-bot-token-here
   ```

3. เปิด **Privileged Gateway Intents** ในหน้า Discord Developer Portal ของบอท:
   - Server Members Intent (ใช้กับ `/role addall`, `/kick`, `/autoguildtag`)
   - Presence Intent (ใช้ตรวจจับ Server Tag ใน `/autoguildtag`)

4. เชิญบอทเข้าเซิร์ฟเวอร์ด้วยสิทธิ์อย่างน้อย: `Manage Roles`, `Manage Channels`,
   `Kick Members`, `Ban Members`, `Moderate Members`, `Manage Messages`,
   `Manage Emojis and Stickers`, `Connect`/`Speak` (สำหรับ `/voicechat`)

5. รันบอท:
   ```bash
   python main.py
   ```

## หมายเหตุการออกแบบ (สมมติฐานที่ผมเลือกให้ในจุดที่สเปคไม่ได้ระบุรายละเอียด)

- **`/ban`**: ตามสเปคเขียนว่า "เปิดหรือปิดระบบแบนสมาชิก" (ไม่ใช่แบนโดยตรง) — ผมตีความว่าเป็น
  **toggle** เก็บสถานะไว้ต่อเซิร์ฟเวอร์ ผ่านตัวเลือก `state: เปิด/ปิด`
  ถ้าต้องการให้เป็นคำสั่งแบนสมาชิกจริง ๆ (ระบุ member + เหตุผล) บอกมาได้ ปรับให้ได้ทันที
- **`/mute`**: ใช้ Discord Timeout (`Member.timeout`) แทนการสร้างยศ Muted แยก เพราะเสถียรกว่า
  และไม่ต้องตั้งสิทธิ์ทุกห้องเอง (ฟังก์ชัน `get_or_create_mute_role` เตรียมไว้ให้เผื่อสลับวิธี)
- **`/ระบบรับยศ77`**: เมนูเลือกจังหวัดถูกแบ่งเป็นหลาย dropdown (25 รายการ/อัน ตามข้อจำกัดของ
  Discord) รวม 4 ชุดสำหรับ 77 จังหวัด เลือก/ยกเลิกจังหวัดในดรอปดาวน์เดียวกันได้อิสระ
- **`/autoguildtag`**: อิงจากฟีเจอร์ "Server Tag" (primary guild identity) ที่ Discord เปิดตัวปี 2024
  ต้องเปิด Presence/Member intent และรอ `on_presence_update`/`on_member_update` จาก Discord
  ซึ่งอาจหน่วงเวลาบ้างตามธรรมชาติของ event นี้
- ปุ่ม/ดรอปดาวน์ทุกตัวที่ต้อง "อยู่ถาวร" (ticket, verify, confess, เลือกยศจังหวัด) ใช้ `custom_id`
  คงที่และถูก `bot.add_view(...)` ใน `setup()` ของแต่ละ cog เพื่อให้ยังกดได้หลัง restart บอท

## คำสั่งทั้งหมด

ดูรายละเอียดทั้งหมดได้จาก `/help` ในตัวบอทเอง (มีเมนูเลือกหมวดหมู่)
