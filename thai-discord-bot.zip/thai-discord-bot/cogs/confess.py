import discord
from discord import app_commands
from discord.ext import commands

import config
import storage


def status_view(title: str, desc: str, color: int = config.COLOR_SUCCESS) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView()
    view.add_item(discord.ui.Container(discord.ui.TextDisplay(f"### {title}\n{desc}"), accent_colour=color))
    return view


class ConfessModal(discord.ui.Modal, title="ฝากบอกแบบไม่ระบุตัวตน"):
    text = discord.ui.TextInput(label="ข้อความของคุณ", style=discord.TextStyle.paragraph,
                                 max_length=1500, placeholder="พิมพ์สิ่งที่อยากบอกที่นี่...")

    def __init__(self, target_channel_id: int):
        super().__init__()
        self.target_channel_id = target_channel_id

    async def on_submit(self, interaction: discord.Interaction):
        channel = interaction.guild.get_channel(self.target_channel_id)
        if channel is None:
            return await interaction.response.send_message("ไม่พบห้องฝากบอก กรุณาติดต่อแอดมิน", ephemeral=True)

        number = storage.get_value(interaction.guild_id, "confess_counter", 0) + 1
        storage.set_value(interaction.guild_id, "confess_counter", number)

        container = discord.ui.Container(
            discord.ui.TextDisplay(f"### 🤫 ฝากบอก #{number}\n{self.text.value}"),
            accent_colour=config.COLOR_PRIMARY,
        )
        v = discord.ui.LayoutView()
        v.add_item(container)
        await channel.send(view=v)
        await interaction.response.send_message("ส่งข้อความของคุณแบบไม่ระบุตัวตนแล้ว ✅", ephemeral=True)


class ConfessButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="ฝากบอก", style=discord.ButtonStyle.primary,
                          emoji="🤫", custom_id="confess_open_modal")

    async def callback(self, interaction: discord.Interaction):
        target_id = storage.get_value(interaction.guild_id, "confess_channel_id")
        if not target_id:
            return await interaction.response.send_message("ยังไม่ได้ตั้งค่าห้องฝากบอก", ephemeral=True)
        await interaction.response.send_modal(ConfessModal(target_id))


class ConfessPanelView(discord.ui.LayoutView):
    def __init__(self):
        super().__init__(timeout=None)
        container = discord.ui.Container(
            discord.ui.TextDisplay("## 🤫 ฝากบอก\nกดปุ่มด้านล่างเพื่อฝากบอกแบบไม่ระบุตัวตน ข้อความของคุณจะไม่แสดงชื่อผู้ส่ง"),
            discord.ui.Separator(),
            discord.ui.ActionRow(ConfessButton()),
            accent_colour=config.COLOR_PRIMARY,
        )
        self.add_item(container)


class Confess(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="confess_setup", description="ติดตั้งระบบฝากบอกแบบไม่ระบุตัวตน")
    @app_commands.describe(post_channel="ห้องที่จะข้อความฝากบอกถูกส่งไปแสดง",
                            panel_channel="ห้องที่จะแสดงปุ่มฝากบอก (ค่าเริ่มต้นคือห้องนี้)")
    @app_commands.checks.has_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def confess_setup(self, interaction: discord.Interaction, post_channel: discord.TextChannel,
                             panel_channel: discord.TextChannel = None):
        panel_channel = panel_channel or interaction.channel
        storage.set_value(interaction.guild_id, "confess_channel_id", post_channel.id)
        await panel_channel.send(view=ConfessPanelView())
        await interaction.response.send_message(
            view=status_view("ติดตั้งสำเร็จ",
                              f"ปุ่มฝากบอกถูกส่งไปที่ {panel_channel.mention}\nข้อความจะถูกโพสต์ที่ {post_channel.mention}"),
            ephemeral=True)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message(
                view=status_view("ไม่มีสิทธิ์", "คุณไม่มีสิทธิ์ใช้คำสั่งนี้", config.COLOR_DANGER), ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Confess(bot))
    bot.add_view(ConfessPanelView())
